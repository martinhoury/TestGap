package plugin.google.maps;

import com.google.android.gms.maps.model.Marker;

public interface PluginMarkerInterface {
  public void onMarkerIconLoaded(Marker marker);
}
